t1 = { 
    "ID" : "01",
    "Lokasi":"Transmart Buah Batu XXI",
    "Film" : ["Wicked", "Kraven the Hunter", "Moana 2"],
    "Wicked": ["09:00 - 11:00", "10:00 - 12:00", "12:30 - 14:30"],
    "Kraven the Hunter": ["09:30 - 11:30", "11:00 - 13:00", "13:00 - 15:00"],
    "Moana 2": ["10:00 - 12:00", "12:00 - 14:00", "14:30 - 16:30"],
    "Kursi_Film_A" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_B" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_C" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"]
}


t2 = { 
    "ID" : "01",
    "Lokasi":"Summarecon Mall Bandung XXI",
    "Film" : ["Avatar: The Way of Water", "Guardians of the Galaxy Vol. 3", "The Flash"],
    "Avatar: The Way of Water": ["09:00 - 11:00", "10:00 - 12:00", "12:30 - 14:30"],
    "Guardians of the Galaxy Vol. 3": ["09:30 - 11:30", "11:00 - 13:00", "13:00 - 15:00"],
    "The Flash": ["10:00 - 12:00", "12:00 - 14:00", "14:30 - 16:30"],
    "Kursi_Film_A" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_B" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_C" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"]
}

t3 = { 
    "ID" : "01",
    "Lokasi":"Braga XXI",
    "Film" : ["Mission Impossible: Dead Reckoning", "Indiana Jones 5", "Oppenheimer"],
    "Mission Impossible: Dead Reckoning": ["09:00 - 11:00", "10:00 - 12:00", "12:30 - 14:30"],
    "Indiana Jones 5": ["09:30 - 11:30", "11:00 - 13:00", "13:00 - 15:00"],
    "Oppenheimer": ["10:00 - 12:00", "12:00 - 14:00", "14:30 - 16:30"],
    "Kursi_Film_A" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_B" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"],
    "Kursi_Film_C" : ["A1", "A2", "A3", "A4", "B1", "B2", "B3", "B4", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4"]
}


lok_theater = {
    "Lokasi": ['Transmart Buah Batu XXI', 'Summarecon Mall Bandung XXI', 'Braga XXI']
}          

pembayaran = {
    "list_type": ["Mandiri", "Dana", "Cash"]
}

riwayat = {
    "List" : []
}

film_reviews = {
    "Mission Impossible: Dead Reckoning": {"ratings": [5, 4], "reviews": ["Bagus sekali!", "Cukup menghibur"]},
    "Indiana Jones 5B": {"ratings": [3, 2], "reviews": ["Kurang menarik", "Cerita membosankan"]},
    "Oppenheimer": {"ratings": [], "reviews": []}
}