import theater_function
import time
# ================ MAIN  =================

# KAMUS GLOBAL
dicT = theater_function

#  ALGORITMA
# Login & Menu
dicT.login()



