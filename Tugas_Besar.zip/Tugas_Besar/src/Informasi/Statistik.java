package Informasi;

public class Statistik {
    // private static Statistik instance;
    // public static Statistik getInstance() {
    //     if (instance == null) {
    //         instance = new Statistik();
    //         }
    //         return instance;
            
    // }

    // private double masaPakai;
    // private int biaya;
    // private int bulan;

    public Statistik() {
        // this.masaPakai = masaPakai;
        // this.biaya = biaya;
        // this.bulan = bulan;
    }

    // public void setBiaya(int biaya) {
    //     this.biaya = biaya;
    // }

    // public void setMasaPakai(double masaPakai) {
    //     this.masaPakai = masaPakai;
    // }

    // public String showMasaPakai() {
    //     return "masaPakai=" + masaPakai;
    // }

    // public String showBiaya() {
    //     return "Biaya = " + biaya;
    // }
}
