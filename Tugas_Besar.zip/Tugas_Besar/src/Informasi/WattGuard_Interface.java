package Informasi;
public interface WattGuard_Interface {
    public void daftarInformasi();
    public void printData(int input);
}
