# planeDetection > 2024-12-16 10:40pm
https://universe.roboflow.com/handiworkspace/planedetection-xokqy

Provided by a Roboflow user
License: CC BY 4.0

